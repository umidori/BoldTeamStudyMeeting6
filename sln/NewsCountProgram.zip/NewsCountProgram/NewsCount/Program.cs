﻿using System;
using System.IO;

namespace NewsCount
{
    internal class Program
    {
        static void Main()
        {
            using (var sr = new StreamReader("news.txt"))
            {
                var lineCount = 0;
                while (sr.ReadLine() != null)
                {
                    lineCount++;
                }
                Console.WriteLine(lineCount);
            }
        }
    }
}
